const express = require('express');
const router = express.Router();

const conn = require('../database');

router.get('/paper', (req,res) => {
    conn.query('Select * from paper', (err, resp, campos) => {
        if(!err){
            res.json(resp);
        }else{
            console.log(err);
        }
    });
});



router.get('/paper/ingresar', (req,res) =>{
    const { id } = req.params;
    conn.query('insert into paper(id_paper, nombre_paper, autor, precio, fecha_lan, id_orden) values (98039045, "investigación cosmética", "alis torres", 10000, "20/04/01", 243581324)', [id], (err, resp, campos) => {
        if(!err){
            //res.json(resp); Mostar Arreglo Json
            res.json(resp[0]); //Mostrar Objeto 
        }else{
            console.log(err);
        }   
    });
});

module.exports = router;