const express = require('express');
const app = express();

// Configuración
app.set('port', process.env.PORT || 3000); 

// Middleware (funciones que se procesan antes de llegar a rutas)
app.use(express.json()); //Transfomar a formato JSON 

// Rutas (URL)
app.use(require('./routes/cliente'));
app.use(require('./routes/paper'));
app.use(require('./routes/orden'));
app.use(require('./routes/administrador'));
// Iniciando Servidor
// app.listen(3000, () => {
//     console.log('Servidor en puerto 3000')
// });
 app.listen(app.get('port'), () => {
     console.log('Servidor en puerto ',app.get('port'))
 });